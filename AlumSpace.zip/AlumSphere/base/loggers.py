import logging

def get_logger():
    return logging.getLogger('app')